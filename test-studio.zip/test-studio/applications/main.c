/*
 * Copyright (c) 2006-2022, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-05-09     RT-Thread    first version
 */
#include <board.h>
#include <rtthread.h>
#include <rtdevice.h>
#include <stdlib.h>
#include<sal.h>
#include<string.h>
#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
#include<sensor.h>
#include<cjson.h>

#include <netdb.h>
#include <sal.h>            /* SAL 组件结构体存放头文件 */
#include <at_socket.h>      /* AT Socket 相关头文件 */
#include <af_inet.h>

#include <netdev.h>         /* 网卡功能相关头文件 */


#include <arpa/inet.h>








int  note=1;
 rt_uint32_t value, vol;







#define PWM_DEV_NAME        "pwm1"  /* PWM设备名称 */
#define PWM_DEV_CHANNEL     1       /* PWM通道 */

struct rt_device_pwm *pwm_dev;      /* PWM设备句柄 */


rt_uint32_t period, pulse, dir;














void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef *htim)
{
    if(htim->Instance==TIM1){
       __HAL_RCC_TIM1_CLK_ENABLE();
    }
}

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim)
{
    if(htim->Instance==TIM1){
        GPIO_InitTypeDef pa;
        pa.Mode = GPIO_MODE_AF_PP;
        pa.Pin = GPIO_PIN_8;
        pa.Speed = GPIO_SPEED_FREQ_MEDIUM;
        pa.Pull = GPIO_NOPULL;
        HAL_GPIO_Init(GPIOA, &pa);
    }
}

void HAL_ADC_MspInit(ADC_HandleTypeDef* hadc)
{
    if(hadc->Instance==ADC1){
        __HAL_RCC_ADC1_CLK_ENABLE();
        GPIO_InitTypeDef pc;
        pc.Mode = GPIO_MODE_ANALOG;
        pc.Pin = GPIO_PIN_1;
        pc.Speed = GPIO_SPEED_FREQ_MEDIUM;
        pc.Pull = GPIO_NOPULL;
        HAL_GPIO_Init(GPIOC, &pc);
    }
}





int pwm(rt_uint32_t  zhankong)
{
    period = 500000;    /* 周期为0.5ms，单位为纳秒ns */
       dir = 1;            /* PWM脉冲宽度值的增减方向 */
       pulse = 0;          /* PWM脉冲宽度值，单位为纳秒ns */

    /* 查找设备 */
    pwm_dev = (struct rt_device_pwm *)rt_device_find(PWM_DEV_NAME);
    if (pwm_dev == RT_NULL)
    {
        rt_kprintf("pwm sample run failed! can't find %s device!\n", PWM_DEV_NAME);
        return RT_ERROR;
    }

    /* 设置PWM周期和脉冲宽度默认值 */
    rt_pwm_set(pwm_dev, PWM_DEV_CHANNEL, period, pulse);
    /* 使能设备 */
    rt_pwm_enable(pwm_dev, PWM_DEV_CHANNEL);

    //  设置PWM周期和脉冲宽度
    rt_pwm_set(pwm_dev, PWM_DEV_CHANNEL, period, zhankong);
}


#define ADC_DEV_NAME        "adc1"      /* ADC 设备名称 */
#define ADC_DEV_CHANNEL     11           /* ADC 通道 */
#define REFER_VOLTAGE       330         /* 参考电压 3.3V,数据精度乘以100保留2位小数*/
#define CONVERT_BITS        (1 << 12)   /* 转换位数为12位 */

 int adc_simple()
{

    rt_adc_device_t adc_dev;
    //rt_uint32_t value, vol;
    rt_err_t ret = RT_EOK;

    /* 查找设备 */
    adc_dev = (rt_adc_device_t)rt_device_find(ADC_DEV_NAME);
    if (adc_dev == RT_NULL)
    {
        rt_kprintf("adc sample run failed! can't find %s device!\n", ADC_DEV_NAME);
        return RT_ERROR;
    }

    /* 使能设备 */
    ret = rt_adc_enable(adc_dev, ADC_DEV_CHANNEL);

    /* 读取采样值 */
    value = rt_adc_read(adc_dev, ADC_DEV_CHANNEL);
    rt_kprintf("the value is :%d \n", value);

    /* 转换为对应电压值 */
    vol = value * REFER_VOLTAGE / CONVERT_BITS;
    rt_kprintf("the voltage is :%d.%02d \n", vol / 100, vol % 100);

    /* 关闭通道 */
    ret = rt_adc_disable(adc_dev, ADC_DEV_CHANNEL);

    return ret;
}







#define SERVER_HOST   "47.99.214.175"
#define SERVER_PORT   28082
 int sockfd = -1;
    struct sockaddr_in server_addr;

 int bing_test()
{


    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        rt_kprintf("Socket create failed.\n");
        return -RT_ERROR;
    }
    /* 初始化预连接的服务端地址 */
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr(SERVER_HOST);
    rt_memset(&(server_addr.sin_zero), 0, sizeof(server_addr.sin_zero));

    /* 连接到服务端 */
    if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) < 0)
    {
        rt_kprintf("socket connect failed!\n");
        closesocket(sockfd);
        return -RT_ERROR;
    }
    else
    {
        rt_kprintf("socket connect success!\n");
    }

    char asd[]="{\"method\":\"authenticate\",\"uid\":\"710877909921\",\"key\":\"U1IBWlYGDlJcWlYIYFheXFhASmY\",\"version\":\"0.1.0\",\"autodb\":true}";
            send(sockfd, asd, strlen(asd),0);
            recv(sockfd, asd, strlen(asd), 0);
            char ac[]="{\"method\":\"sensor\",\"addr\":\"56:12:4B:00:02:63:4C:4F\",\"data\":\"{A0=?}\"}";
                      send(sockfd, ac, strlen(ac),0);
                      rt_thread_mdelay(1000);
                      send(sockfd, ac, strlen(ac),0);
                      rt_thread_mdelay(1000);
                      send(sockfd, ac, strlen(ac),0);
                      rt_thread_mdelay(1000);
                      send(sockfd, ac, strlen(ac),0);
                      rt_thread_mdelay(1000);
            return RT_EOK;
}
 int shou(){

      typedef struct{
          char method[32];
          int data;
          char addr[32];
      }PERSON;
     char adds[400];

     while(1){
         int a=recv(sockfd, adds, 400, 0);
         if(a<0)
         {
             rt_kprintf("error");
             continue;
         }
             adds[a]=0;
            cJSON*root=cJSON_Parse(adds);
            cJSON*item;
            cJSON*tmp;
            PERSON person;
            item=cJSON_GetObjectItem(root, "data");

            char asd[32];
            memcpy(asd,item->valuestring,strlen(item->valuestring));
            cJSON*hoot=cJSON_Parse(asd);
           tmp=cJSON_GetObjectItem(hoot, "A0");


            person.data=tmp->valueint;
            pwm(person.data);
            rt_kprintf("%d\n",person.data);


          }
    return RT_EOK;

}
 int du(){

        int n=100;
        long long  j=500000;
        int size=strlen("{\"method\":\"sensor\",\"addr\":\"56:12:4B:00:02:63:4C:4F\",\"data\":\"{A0=120}\",}");
        char tmp[size+10];

       while(1){
           adc_simple();
           rt_thread_mdelay(1000);
           sprintf(tmp,"{\"method\":\"sensor\",\"addr\":\"56:12:4B:00:02:63:4C:4F\",\"data\":\"{A0=%d,vol=%f}\"}",value,(value * REFER_VOLTAGE / CONVERT_BITS/100)+(value * REFER_VOLTAGE / CONVERT_BITS)%100*0.01);
           send(sockfd, tmp, strlen(tmp),0);
           if(value>0&&value<=500)
           {
               pwm(50000);
           }
           else if(value>500&&value<=800)
           {
               pwm(42000);
           }
           else if(value>800&&value<=1000)
            {
                    pwm(350000);
            }
           else if(value>1000&&value<=1300)
           {
               pwm(25000);
           }
           else if(value>1300&&value<=1500)
                {
                          pwm(22000);
                 }
           else if(value>1500&&value<=1800)
           {
               pwm(19000);
           }
           else if(value>1800&&value<=2000)
                  {
                      pwm(16000);
                  }
           else if(value>2000&&value<=2300)
           {
               pwm(15000);
           }
           else if(value>2300&&value<=2500)
           {
               pwm(10000);
           }
           else if(value>2300&&value<=2500)
           {
               pwm(10000);
           }
           else if(value>2500&&value<=2800)
           {
               pwm(5000);
           }
           else if(value>2800&&value<=3000)
           {
               pwm(2500);
           }
           else
           {
               pwm(0);

           }
           while(j--);
           j=500000;
       }

    /* 关闭连接 */

    return RT_EOK;
}




#define THREAD_PRIORITY         25
#define THREAD_STACK_SIZE      8192
#define THREAD_TIMESLICE        5

/*static rt_thread_t tid1 = RT_NULL;*/

/* 线程 1 的入口函数 */
/*static void thread1_entry(void *parameter)
{

    bing_test();
}*/

ALIGN(RT_ALIGN_SIZE)
 char thread1_stack[2048];
 struct rt_thread thread1;
/* 线程 1  入口 */
 static void thread1_entry(void *param)
{


     while(1)
     {
             du();

     }


}


ALIGN(RT_ALIGN_SIZE)
 char thread2_stack[2048];
 struct rt_thread thread2;
/* 线程 2 入口 */
 static void thread2_entry(void *param)
{

     shou();
}

/* 线程示例 */
int thread_sample(void)
{
    /* 创建线程 1，名称是 thread1，入口是 thread1_entry*/
    /*tid1 = rt_thread_create("thread1",
                            thread1_entry, RT_NULL,
                            THREAD_STACK_SIZE,
                            THREAD_PRIORITY  , THREAD_TIMESLICE);*/

    /* 如果获得线程控制块，启动这个线程 */
    /*if (tid1 != RT_NULL)
        rt_thread_startup(tid1);*/
    rt_thread_init(&thread1,
                     "thread1",
                     thread1_entry,
                     RT_NULL,
                     &thread1_stack[0],
                     sizeof(thread1_stack),
                     THREAD_PRIORITY-1 , THREAD_TIMESLICE);
      rt_thread_startup(&thread1);
    /* 初始化线程 2，名称是 thread2，入口是 thread2_entry */
    rt_thread_init(&thread2,
                   "thread2",
                   thread2_entry,
                   RT_NULL,
                   &thread2_stack[0],
                   sizeof(thread2_stack),
                   THREAD_PRIORITY  , THREAD_TIMESLICE);
    rt_thread_startup(&thread2);

    return 0;
}




int main(void)
{

    rt_thread_mdelay(5000);
   bing_test();



    return RT_EOK;
}



/* 导出到 msh 命令列表中 */
MSH_CMD_EXPORT(adc_simple, adc );
MSH_CMD_EXPORT(pwm, adc );

/* 导出到 msh 命令列表中 */
MSH_CMD_EXPORT(thread_sample, thread sample);


MSH_CMD_EXPORT(bing_test, bind network interface device test);

MSH_CMD_EXPORT(shou, bind network interface device test);
MSH_CMD_EXPORT(du, bind network interface device test);
